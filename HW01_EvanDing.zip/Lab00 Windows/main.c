#define RGB(R, G, B) ((R) | (G) << 5 | (B) << 10)
#define REG_DISPCNT (*(volatile unsigned short *)0x04000000)
#define MODE3 3
#define BG2_ENABLE (1<<10)
#define VIDEO_BUFFER ((volatile unsigned short *)0x06000000)
#define REG_KEYINPUT (*(volatile u16*)0x04000130)
#define KEY_A        0x0001
#define KEY_B        0x0002
#define KEY_SELECT   0x0004
#define KEY_START    0x0008
#define KEY_RIGHT    0x0010
#define KEY_LEFT     0x0020
#define KEY_UP       0x0040
#define KEY_DOWN     0x0080
#define KEY_R        0x0100
#define KEY_L        0x0200
#define SetPixel(x, y, val) (VIDEO_BUFFER[(x) + (y)*240] = val)
#define BUTTONS (*(volatile u16*) 0x4000130)
#define BUTTON_PRESSED(key) ((!(~oldButtons&(key))) && (~buttons&(key)))


typedef unsigned short u16;
typedef unsigned char u8;
volatile u16* scanlineCounter = (u16*) 0x04000006;

unsigned short buttons;
unsigned short oldButtons ;
 
int x; int y; int prevxcord; int prevycord; int counter=0; color = 0;
 
 
void drawSquare(int x, int y, int size, u16 color){
 for (int i=0; i<size; i++){
   for (int j=0; j<size; j++){
     SetPixel(x+i, y+j, color);
   }
 }
}
void drawRectangle(int x, int y, int h, int l, u16 color) {
for (int i=0; i<h; i++){
   for (int j=0; j<l; j++){
     SetPixel(x+i, y+j, color);
   }
 }
}
 
void drawHelp(int x, int y,u16 color) {
   int size = 1;
  drawRectangle(x,y,12,12,color);
}

void drawObj(int x, int y, u16 color){
drawHelp(x,y,color);
drawHelp(x+12,y+12,color);
drawHelp(x+24,y+24,color);
drawHelp(x+36,y+36,color);
}
void hidePREV(int x,int  y) {
   drawHelp(x,y,0);
   drawHelp(x+12,y+12,0);
    drawHelp(x+24,y+24,0);
drawHelp(x+36,y+36,0);
drawSquare(x+6,y+6,3,0);
drawSquare(x+12,y+12,3,0);
drawSquare(x+6,y+6,3,0);


}
void waitForVBlank() {
    while (*scanlineCounter >= 160);  // wait until current VBlank ends
 while (*scanlineCounter < 160);  // wait until next VBlank starts
}
 
 
void update () {
 
if(BUTTON_PRESSED(KEY_A)) {

   if(counter ==2) {
    prevxcord = x; prevycord = y;
    x = 10; y =10;
    counter = 3;
    color = RGB(20,0,0);
     }
 
 
    else if(counter ==1) {
    prevxcord = x; prevycord = y;
    x = 25; y =50;
    counter = 2;
    color = RGB(0,20,0);
   
    }
 
    else if(counter ==0){
   prevxcord = x; prevycord = y;
    x = 60; y =70;
    counter = 1;
    color = RGB(0,0,20);
    }
    else if(counter == 3){
   prevxcord = x; prevycord = y;
    x = 60; y =15;
    counter = 0;
    color = RGB(20,20,0);
}
 
}
 
if(BUTTON_PRESSED(KEY_B)) {
 
   if(counter ==2) {
    prevxcord = x; prevycord = y;
    x = 60; y =70;
    counter = 1;
    color = RGB(0,0,20);}
 
    else if(counter ==0) {
   prevxcord = x; prevycord = y;
    x = 10; y =10;
    counter = 3;
    color = RGB(20,0,0);
    }
 
    else if(counter ==1){
        prevxcord = x; prevycord = y;
    x = 60; y =15;
    counter = 0;
    color = RGB(20,20,0);
    }
 
   else if(counter == 3){
     prevxcord = x; prevycord = y;
    x = 25; y =50;
    counter = 2;
    color = RGB(0,20,0);
   }
}
}
 
 
void draw () {
hidePREV(prevxcord,prevycord);
drawObj(x,y,color);
}
int main() {
 
 REG_DISPCNT = MODE3 | BG2_ENABLE;
 
 
 
 while (1) {
  
   oldButtons= buttons;
   buttons = BUTTONS;
  
    update();
    waitForVBlank();
    draw();
    
 
 

 
 
 }
 return 0;
}

